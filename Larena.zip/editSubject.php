<?php
 $conn = mysqli_connect('localhost','encoder','encoder','school');

// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}

if(isset($_POST['updatesubj']))
{    
    $id = $_POST['id'];
    $code=$_POST['code']; 
	$title=$_POST['title']; 
	$unit=$_POST['unit']; 
    
    // checking empty fields
    if(empty($code)) {            
        if(empty($code)) {
            echo "<font color='red'>Subject Code field is empty.</font><br/>";
        }   
    } else {    
        $result = mysqli_query($conn, "UPDATE subject SET code='$code',title='$title',unit='$unit' WHERE id=$id");
        header("Location: subjects.php");
    }
}

//getting id from url
$id = $_GET['id'];
 
//selecting data associated with this particular id
$sql =  "SELECT code,title,unit FROM subject WHERE id=$id";
$result = mysqli_query($conn,$sql) or die(mysqli_error($conn));
 
while($res = mysqli_fetch_array($result))
{
    $code = $res['code'];
	$title = $res['title'];
	$unit = $res['unit'];
}
?>
<html>
<body>
    <br/><br/>
    
    <form name="form1" method="post" action="editSubject.php">
        <table border="0">
            <tr> 
                <td>Code</td>
                <td><input type="text" name="code" value="<?php echo $code;?>"></td>
            </tr>
			 <tr> 
                <td>Title</td>
                <td><input type="text" name="title" value="<?php echo $title;?>"></td>
            </tr>
			 <tr> 
                <td>Year</td>
                <td><input type="text" name="unit" value="<?php echo $unit;?>"></td>
            </tr>

                <td><input type="hidden" name="id" value=<?php echo $_GET['id'];?>></td>
                <td><input type="submit" name="updatesubj" value="Update"></td>
        </table>
    </form>
</body>
</html>
