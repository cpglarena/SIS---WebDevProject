<?php
   include('session.php');
?>
<html>
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>

<style>
table {
	border-collapse: collapse;
	width: 70%;
	}
td, th{
	font-family:Century Gothic; 
	text-align:center;
 border-bottom: 1px solid #ddd;
 padding: 15px;
		}
	th{ background-color: black;
		color: white;}
	p {text-align:center; 
	   font-family:Century Gothic;}
	.holder{ text-align:center; }
.not-active {
   pointer-events: none;
   cursor: default;
   content='For authorized personnel only';
}	
</style>
</head>
<body>

<nav class="navbar navbar-inverse">
	<div class="container-fluid">
		<div class="navbar-header">
			<a class="navbar-brand" href="#">School</a>
		</div>
		<ul class="nav navbar-nav">
			<li><a href='student.php'>Student</a></li>
			<li><a href='programs.php'>Programs</a></li>
			<li><a href='subjects.php'>Subject</a></li>
			<li><a href='grades.php'>Grade</a></li>
			<li><a href='nationality.php'>Nationality</a></li>
			<li><a href='religion.php'>Religion</a></li>
			<li><a href='account.php'>Accounts</a></li>
			<li><a href='logout.php'>Logout</a></li>	
	</div>
</nav>
<br>
<h2 font-family = "Century Gothic"><center>Grades </h2>
<div class="container">
	<h1> </h1>
	<div class = "holder">
	<button type="button" class="btn btn-default btn-sm" data-toggle="modal" data-target="#pop">Add</button>
	</div> </div>
	<br>
  <!-- Modal -->
  <div class="modal fade" id="pop" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          
		<form action="insert.php" method="post" name="insertform">
		<table>
		<tr>
		<td><label for="mobile" id="preinput"> Code : </label>
		<input type="text" name="subject_id" /></td></tr>
		<tr><td><label for="mobile" id="preinput"> Grade :&nbsp; </label>
		<input type="text" name="grade" /></td></tr>
		<tr><td><label for="mobile" id="preinput"> Semester : &nbsp;&nbsp;&nbsp;</label>
		<input type="text" name="semester" /></td></tr>
		</tr>
		<tr><td><label for="mobile" id="preinput"> School Year : &nbsp;&nbsp;&nbsp;</label>
		<input type="text" name="schoolyear" /></td></tr>
		</tr>
		</table>
		<p>
		<input type="submit" name="sendgrade" value="Add" id="inputid1" disabled />
		</p>
		</form>
      </div>
    </div>
  </div>
</div>
<div class='row'>
                <div class='col-lg-12'>
                    <div class='panel panel-default'>
                        <div class='panel-body'>
                            <table width='100%' class='table table-striped table-bordered table-hover' id='dataTables-example'>
                                <thead>
                                    <tr>
                                        <th> Subject Code </th>
                                        <th>Grade</th>
										<th>Semester</th>
										<th>School Year</th>
										<th> Option </th>
                                    </tr>
                                </thead>
								<tbody>
<?php

// Create connection
$conn = mysqli_connect('localhost','root','','school');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
   $sql="SELECT subject_id,grade.grade,semester,schoolyear FROM grade";
  $result = mysqli_query($conn,$sql) or die(mysqli_error($conn));
	$tableName = 'grade';
  while($row=mysqli_fetch_array($result))
  { 
	 echo" <tr>
		<td>".$row['subject_id']."</td>
		<td>".$row['grade']."</td>
		<td>".$row['semester']."</td>
		<td>".$row['schoolyear']."</td>
		<td><a href=\"editGrade.php?id=$row[subject_id]\" data-target='#pop2' data-toggle = 'modal'>Edit</a> | <a href=\"delete.php?id=$row[id]&tablen=$tableName\" onClick=\"return confirm('Are you sure you want to delete?')\" name = 'delRel'>Delete</a></td>";
  }
  mysqli_close($conn);
?>
<footer align='bottom'><p><b> Copyright: Coleen Pia Larena </b></p></footer>
<div class="modal fade" id="pop2" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
     
		
       
</div>
</div>
</body>
</html>