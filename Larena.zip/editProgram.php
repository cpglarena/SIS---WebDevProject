<?php
 $conn = mysqli_connect('localhost','encoder','encoder','school');

// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}

if(isset($_POST['updateprog']))
{    
    $id = $_POST['id'];
    $code=$_POST['code']; 
	$title=$_POST['title']; 
	$year=$_POST['year']; 
    
    // checking empty fields
    if(empty($code)) {            
        if(empty($code)) {
            echo "<font color='red'>Subject Code field is empty.</font><br/>";
        }   
    } else {    
        $result = mysqli_query($conn, "UPDATE program SET code='$code',title='$title',year='$year' WHERE id=$id");
        header("Location: programs.php");
    }
}

//getting id from url
$id = $_GET['id'];
 
//selecting data associated with this particular id
$sql =  "SELECT code,title,year FROM program WHERE id=$id";
$result = mysqli_query($conn,$sql) or die(mysqli_error($conn));
 
while($res = mysqli_fetch_array($result))
{
    $code = $res['code'];
	$title = $res['title'];
	$year = $res['year'];
}
?>
<html>
<body>
    <br/><br/>
    
    <form name="form1" method="post" action="editProgram.php">
        <table border="0">
            <tr> 
                <td>Code</td>
                <td><input type="text" name="code" value="<?php echo $code;?>"></td>
            </tr>
			 <tr> 
                <td>Title</td>
                <td><input type="text" name="title" value="<?php echo $title;?>"></td>
            </tr>
			 <tr> 
                <td>Year</td>
                <td><input type="text" name="year" value="<?php echo $year;?>"></td>
            </tr>

                <td><input type="hidden" name="id" value=<?php echo $_GET['id'];?>></td>
                <td><input type="submit" name="updateprog" value="Update"></td>
        </table>
    </form>
</body>
</html>
