<?php
 $conn = mysqli_connect('localhost','encoder','encoder','school');

// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}

if(isset($_POST['updateacct']))
{    
    $id = $_POST['id'];
    $uname=$_POST['uname']; 
	$pword=$_POST['pword']; 
	$description=$_POST['description']; 
	$active=$_POST['active']; 
    
    // checking empty fields
    if(empty($uname)) {            
        if(empty($uname)) {
            echo "<font color='red'>Username field is empty.</font><br/>";
        }  
		else if(empty($pword)) {
            echo "<font color='red'>Password field is empty.</font><br/>";
        }  		
    } else {    
        $result = mysqli_query($conn, "UPDATE account SET uname='$uname',pword='$pword',description='$description',active='$active' WHERE id=$id");
        header("Location: accounts.php");
    }
}

//getting id from url
$id = $_GET['id'];
 
//selecting data associated with this particular id
$sql =  "SELECT uname,pword,description,active FROM account WHERE id=$id";
$result = mysqli_query($conn,$sql) or die(mysqli_error($conn));
 
while($res = mysqli_fetch_array($result))
{
    $uname = $res['uname'];
	$pword = $res['pword'];
	$description = $res['description'];
	$active = $res['active'];
}
?>
<html>
<body>
    <br/><br/>
    
    <form name="form1" method="post" action="editAccount.php">
        <table border="0">
            <tr> 
                <td>Username</td>
                <td><input type="text" name="uname" value="<?php echo $uname;?>"></td>
            </tr>
			 <tr> 
                <td>Password</td>
                <td><input type="text" name="pword" value="<?php echo $pword;?>"></td>
            </tr>
			 <tr> 
                <td>Description</td>
                <td><input type="text" name="description" value="<?php echo $description;?>"></td>
            </tr>
			 <tr> 
                <td>Active</td>
                <td><input type="text" name="active" value="<?php echo $active;?>"></td>
            </tr>

                <td><input type="hidden" name="id" value=<?php echo $_GET['id'];?>></td>
                <td><input type="submit" name="updateacct" value="Update"></td>
        </table>
    </form>
</body>
</html>
