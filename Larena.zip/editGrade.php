<?php
 $conn = mysqli_connect('localhost','encoder','encoder','school');

// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}

if(isset($_POST['updategrd']))
{    
    $id = $_POST['id'];
    $subject_id=$_POST['subject_id']; 
	$grade=$_POST['grade']; 
	$semester=$_POST['semester']; 
	$schoolyear=$_POST['schoolyear']; 
    
    // checking empty fields
    if(empty($grade)) {            
        if(empty($grade)) {
            echo "<font color='red'>Grade field is empty.</font><br/>";
        }   
    } else {    
        $result = mysqli_query($conn, "UPDATE grade SET subject_id='$subject_id', grade='$grade', semester='$semester',schoolyear='$schoolyear' WHERE id=$id");
        header("Location: grades.php");
    }
}

//getting id from url
$id = $_GET['id'];
 
//selecting data associated with this particular id
$sql =  "SELECT subject_id,grade,semester,schoolyear FROM grade WHERE id=$id";
$result = mysqli_query($conn,$sql) or die(mysqli_error($conn));
 
while($res = mysqli_fetch_array($result))
{
    $subject_id = $res['subject_id'];
	$grade = $res['grade'];
	$semester = $res['semester'];
	$schoolyear = $res['schoolyear'];
}
?>
<html>
<body>
    <br/><br/>
    
    <form name="form1" method="post" action="editGrade.php">
        <table border="0">
            <tr> 
                <td>Code</td>
                <td><input type="text" name="subject_id" value="<?php echo $subject_id;?>"></td>
            </tr>
			 <tr> 
                <td>Grade</td>
                <td><input type="text" name="grade" value="<?php echo $grade;?>"></td>
            </tr>
			 <tr> 
                <td>Semester</td>
                <td><input type="text" name="semester" value="<?php echo $semester;?>"></td>
            </tr>
			 <tr> 
                <td>School Year</td>
                <td><input type="text" name="schoolyear" value="<?php echo $schoolyear;?>"></td>
            </tr>

                <input type="hidden" name="id" value=<?php echo $_GET['id'];?>>
              <td>  <input type="submit" name="updategrd" value="Update"> </td>
        </table>
    </form>
</body>
</html>
