<?php
   define('DB_SERVER', 'localhost');
   define('DB_USERNAME', 'encoder');
   define('DB_PASSWORD', 'encoder');
   define('DB_DATABASE', 'school');
   $db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
?>