<?php
 $conn = mysqli_connect('localhost','encoder','encoder','school');

// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}

if(isset($_POST['updatestud']))
{    
    $id = $_POST['id'];
    $code=$_POST['code']; 
	$title=$_POST['title']; 
	$unit=$_POST['unit']; 
	$code=$_POST['code']; 
	$title=$_POST['title']; 
	$unit=$_POST['unit']; 
	$code=$_POST['code']; 
	$title=$_POST['title']; 
	$unit=$_POST['unit']; 
	$code=$_POST['code']; 
    
    // checking empty fields
    if(empty($ln)) {            
        if(empty($ln)) {
            echo "<font color='red'>Last Name field is empty.</font><br/>";
        }   
    } else {    
        $result = mysqli_query($conn, "UPDATE student SET lastname = '$ln',firstname = '$fn',middlename = '$mn',gender = '$gen',birthdate = '$bdate',program.code,nationality.name,religion.name,regular = '$reg',year = '$yr' FROM student LEFT JOIN program ON student.program_id = program.id LEFT JOIN nationality ON student.nationality_id = nationality.id LEFT JOIN religion ON student.religion_id = religion.id  WHERE id=$id");
        header("Location: student.php");
    }
}

//getting id from url
$id = $_GET['id'];
 
//selecting data associated with this particular id
$sql =  "SELECT id,lastname,firstname,middlename,gender,birthdate,program.code,nationality.name,religion.name,regular,year FROM student LEFT JOIN program ON student.program_id = program.id LEFT JOIN nationality ON student.nationality_id = nationality.id LEFT JOIN religion ON student.religion_id = religion.id WHERE id=$id";
$result = mysqli_query($conn,$sql) or die(mysqli_error($conn));
 
while($res = mysqli_fetch_array($result))
{
    $ln= $res['ln'];
	$fn = $res['fn'];
	$mn = $res['mn'];
	$gen = $res['gen'];
	$bdate = $res['bdate'];
	$prog = $res['prog'];
	$nat = $res['nation'];
	$rel = $res['rel'];
	$reg = $res['reg'];
	$yr = $res['yr'];
}
?>
<html>
<body>
    <br/><br/>
    
    <form name="form1" method="post" action="editStudent.php">
        <table border="0">
            <tr> 
                <td>Last Name</td>
                <td><input type="text" name="ln" value="<?php echo $ln;?>"required></td>
            </tr>
			 <tr> 
                <td>First Name</td>
                <td><input type="text" name="fn" value="<?php echo $fn;?>" required /></td>
            </tr>
			 <tr> 
                <td>Middle Name</td>
                <td><input type="text" name="mn" value="<?php echo $mn;?>"required></td>
            </tr>
			   <tr> 
                <td>Gender</td>
                <td><input type="text" name="gen" value="<?php echo $gen;?>" required></td>
            </tr>
			 <tr> 
                <td>Birth Date</td>
                <td><input type="text" name="bdate" value="<?php echo $bdate;?>"required></td>
            </tr>
			 <tr> 
                <td>Program</td>
                <td><input type="text" name="prog" value="<?php echo $prog;?>" required></td>
            </tr>
			   <tr> 
                <td>Nationality</td>
                <td><input type="text" name="nation" value="<?php echo $nat;?>"required></td>
            </tr>
			 </tr>
			   <tr> 
                <td>Religion</td>
                <td><input type="text" name="rel" value="<?php echo $rel;?>"></td>
            </tr>
			 <tr> 
                <td>Regular</td>
                <td><input type="text" name="reg" value="<?php echo $reg;?>"></td>
            </tr>
			 <tr> 
                <td>Year</td>
                <td><input type="text" name="yr" value="<?php echo $yr;?>"></td>
            </tr>
			<input type="hidden" name="id" value=<?php echo $_GET['id'];?>></td>
                <td><input type="submit" name="updatestud" value="Update"></td>
        </table>
    </form>
</body>
</html>
