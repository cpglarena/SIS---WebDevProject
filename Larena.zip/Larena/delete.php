<?php
$conn = mysqli_connect('localhost','encoder','encoder','school');

// Check connection
	if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
	} 
//getting id of the data from url
$id = $_GET['id'];
$title = $_GET['tablen'];

 
//deleting the row from table
$result = mysqli_query($conn, "DELETE FROM ".$title." WHERE id=$id");

if($title === 'religion'){
	header("Location:religion.php");
}
else if($title === 'student'){
	header("Location:student.php");
}
else if($title === 'subject'){
	header("Location:subjects.php");
}
else if($title === 'program'){
	header("Location:programs.php");
}
else if($title === 'nationality'){
	header("Location:nationality.php");
}
else if($title === 'account'){
	header("Location:accounts.php");
}
else if($title === 'grade'){
	header("Location:grades.php");
}
?>