<?php
 $conn = mysqli_connect('localhost','encoder','encoder','school');

// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}

if(isset($_POST['updatesubj']))
{    
    $id = $_POST['id'];
    $name=$_POST['name']; 
    
    // checking empty fields
    if(empty($name)) {            
        if(empty($name)) {
            echo "<font color='red'>Name field is empty.</font><br/>";
        }   
    } else {    
        $result = mysqli_query($conn, "UPDATE nationality SET name='$name' WHERE id=$id");
        header("Location: nationality.php");
    }
}

//getting id from url
$id = $_GET['id'];
 
//selecting data associated with this particular id
$sql =  "SELECT name FROM nationality WHERE id=$id";
$result = mysqli_query($conn,$sql) or die(mysqli_error($conn));
 
while($res = mysqli_fetch_array($result))
{
    $name = $res['name'];
}
?>
<html>
<body>
    <br/><br/>
    
    <form name="form1" method="post" action="editNation.php">
        <table border="0">
            <tr> 
                <td>Name</td>
                <td><input type="text" name="name" value="<?php echo $name;?>"></td>
            </tr>

                <input type="hidden" name="id" value=<?php echo $_GET['id'];?>>
              <td>  <input type="submit" name="updatesubj" value="Update"> </td>
        </table>
    </form>
</body>
</html>
