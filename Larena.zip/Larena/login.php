<?php
   include("connect.php");
   session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      
      $user = mysqli_real_escape_string($db,$_POST['log']);
      $pass = mysqli_real_escape_string($db,$_POST['pwd']); 
      
      $sql = "SELECT id FROM account WHERE uname = '$user' and pword = '$pass'";
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      $active = $row['active'];
      
      $count = mysqli_num_rows($result);
      
      
		
      if($count == 1) {
		 $_SESSION['login_user'] = $user;
         header("location: student.php");
      }else {
         $error = "Invalid username or password. Please try again.";
      }
   }
	 
echo "
<html>
<head>
	<meta charset='UTF-8'>
  <title></title>
  </head>
  <style>
    html, body, div, span, applet, object, iframe,
    h1, h2, h3, h4, h5, h6, p, blockquote, pre,
    a, abbr, acronym, address, big, cite, code,
    del, dfn, em, img, ins, kbd, q, s, samp,
    small, strike, strong, sub, sup, tt, var,
    b, u, i, center,
    dl, dt, dd, ol, ul, li,
    fieldset, form, label, legend,
    table, caption, tbody, tfoot, thead, tr, th, td,
    article, aside, canvas, details, embed,
    figure, figcaption, footer, header, hgroup,
    menu, nav, output, ruby, section, summary,
    time, mark, audio, video {
    margin: 0;
    padding: 0;
    border: 0;
    font-size: 100%;
    font: inherit;
    vertical-align: baseline;
    }
    /* HTML5 display-role reset for older browsers */
    article, aside, details, figcaption, figure,
    footer, header, hgroup, menu, nav, section {
    display: block;
    }
    body {
    line-height: 1;
    }
    ol, ul {
    list-style: none;
    }
    blockquote, q {
    quotes: none;
    }
    blockquote:before, blockquote:after,
    q:before, q:after {
    content: '';
    content: none;
    }
    table {
    border-collapse: collapse;
    border-spacing: 0;
    }

/* Reset End */

body {
	background: #4EAFCD url('bg.png') repeat;
	position: relative;
	font-family: 'Oswald', sans-serif;
}

.container {
	margin: auto;  
	padding: 215px 0;
}

#loginform {	
	background-color: #f7f7f7;
	display: block;
	height: 190px;
	margin: 0 auto;	
	outline: solid 10px rgba(0,0,0,0.10);
	width: 190px;
	padding: 30px;
}

.login-username:before { 
	content: ' o｜◕ˇ▽ˇ◕｜ツ   ';
	color: #4c4c4c;	
	font-size: 20px;
	margin: 0;
	text-shadow: 0 1px 1px rgba(0,0,0,0.5);
} 
 
 .login-username label, .login-password label {
	display: none;
	text-indent: -9999px;
}
 
.login-username .input{ 
	margin-top: 15px;
 } 

.login-password .input { margin-top: -14px;}
 
 ::-moz-placeholder {  /* Firefox 19+ */
   color: #4c4c4c;
   text-transform: uppercase;
}

::-webkit-input-placeholder {
   color: #5d5b5b;
   text-transform: uppercase;
}

.input { 
	background-color: #fff;
	cursor: text;
	border: solid 1px #dedede; 
	box-sizing: border-box;
	color: #4c4c4c;
	font: 400 13px/18px 'oswald';
	height: 40px;
	margin-bottom: -18px;
	outline: none;
	padding: 8px 15px;
	transition: border 0.3s;
	width:100%;
}

.input:focus { border: solid 1px #f35b5b; }

.login-username:after {
	background-color: #f7f7f7;
	content: '*';	
	color: #f35b5b;
	height: 35px;
	width: 35px;
	float: right;
	font: 400 24px 'oswald';
	line-height: 43px;
	position: relative;
	overflow: hidden;
	right: 2px;
	text-align: center;
	top: -24px;
}

.login-password:after {
	background-color: #f7f7f7;
	content: '*';	
	color: #f35b5b;
	height: 35px;
	width: 35px;
	float: right;
	font: 400 24px 'oswald';
	line-height: 43px;
	position: relative;
	overflow: hidden;
	right: 2px;
	text-align: center;
	top: -24px;
}

.button-primary {
	background-color: #14b9d6;
	border: solid 1px transparent; 
	box-sizing: border-box;
	color: #fff;
	cursor: pointer;
	font:  14px/36px 'oswald';
	height: 42px;
	letter-spacing: 1px;
	margin-top: -11px;
	outline: none;
	text-align: center;
	text-transform: uppercase;
	transition: background-color 0.5s;
	width: 100%;
}

.button-primary:hover {
	background-color: #469DB6;

}
.login-remember { 
	display: none;
}
  </style>

";

echo "
		<body>

<meta charset='UTF-8'>
<title>Sign In form</title>
<link rel='stylesheet' type='text/css' href='style.css'>
<link href='http://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
</head>

<body>
<div id='main' class='container'> 	
	<form name='loginform' id='loginform' action='#' method='post' class='wpl-track-me' method = 'POST'> 
		<p class='login-username'>
		<label for='user_login'>Username</label> 
			<input type='text' name='log' id='user_login' class='input' placeholder='Username' value='' size='20' /> 
		</p> 
		<p class='login-password'> 
		<label for='user_pass'>Password</label><input type='password' name='pwd' id='user_pass' class='input' placeholder='Password' value='' size='20' /> 
		</p> 	
		<p class='login-remember'><label><input name='rememberme' type='checkbox' id='rememberme' value='forever'> Remember Me</label></p>
		<p class='login-submit'><input type='submit' name='wp-submit' id='wp-submit' class='button-primary' value='Log in' />
		<input type='hidden' name='redirect_to' value='#'/>
		</p> 	
	</form> 
</div>
</body>


";

echo"
           <footer align = 'bottom'> Copyright  by Coleen Pia Larena </footer>
		   </html>
   ";
?>

