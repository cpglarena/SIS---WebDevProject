<?php
 ob_start();
	$conn = mysqli_connect('localhost','encoder','encoder','school');

// Check connection
	if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
	}
	
  if(isset($_POST['sendrel'])!="")
  {
		$relname=$_POST['name'];
		$sql="INSERT INTO religion(name)VALUES('$relname')";
		$result = mysqli_query($conn,$sql);
  
	if($result)
	{
      $msg="Successfully Updated!!";
      echo "<script type='text/javascript'>alert('$msg');</script>";
      header('Location:religion.php');
	}
	else
	{
     $errormsg="Something went wrong, Try again";
      echo "<script type='text/javascript'>alert('$errormsg');</script>";
	}
  }
   else if(isset($_POST['sendprog'])!="")
  {
		$code=$_POST['code'];
		$title=$_POST['title'];
		$year=$_POST['year'];
		
		$sql="INSERT INTO program(code,title,year)VALUES('$code','$title','$year')";
		$result = mysqli_query($conn,$sql);
  
	if($result)
	{
      $msg="Successfully Updated!!";
      echo "<script type='text/javascript'>alert('$msg');</script>";
      header('Location:programs.php');
	}
	else
	{
     $errormsg="Something went wrong, Try again";
      echo "<script type='text/javascript'>alert('$errormsg');</script>";
	}
  }
   else if(isset($_POST['sendsubj'])!="")
  {
		$code=$_POST['code'];
		$title=$_POST['title'];
		$unit=$_POST['unit'];
		
		$sql="INSERT INTO subject(code,title,unit)VALUES('$code','$title','$unit')";
		$result = mysqli_query($conn,$sql);
  
	if($result)
	{
      $msg="Successfully Updated!!";
      echo "<script type='text/javascript'>alert('$msg');</script>";
      header('Location:subjects.php');
	}
	else
	{
     $errormsg="Something went wrong, Try again";
      echo "<script type='text/javascript'>alert('$errormsg');</script>";
	}
  }
   else if(isset($_POST['sendnat'])!="")
  {
		$nat=$_POST['name'];
		$sql="INSERT INTO nationality(name)VALUES('$nat')";
		$result = mysqli_query($conn,$sql);
  
	if($result)
	{
      $msg="Successfully Updated!!";
      echo "<script type='text/javascript'>alert('$msg');</script>";
      header('Location:nationality.php');
	}
	else
	{
     $errormsg="Something went wrong, Try again";
      echo "<script type='text/javascript'>alert('$errormsg');</script>";
	}
  }
      else if(isset($_POST['sendgrade'])!="")
  {
		$subject_id=$_POST['subject_id'];
		$grade=$_POST['grade'];
		$semester=$_POST['semester'];
		$schoolyear=$_POST['schoolyear'];
		
		$sql="INSERT INTO grade(subject_id,grade,semester,schoolyear)VALUES('$subject_id','$grade','$semester','$schoolyear')";
		$result = mysqli_query($conn,$sql)  or die (mysqli_error($conn));
	if($result)
	{
      $msg="Successfully Updated!!";
      echo "<script type='text/javascript'>alert('$msg');</script>";
      header('Location:grades.php');
	}
	else
	{
     $errormsg="Something went wrong, Try again";
      echo "<script type='text/javascript'>alert('$errormsg');</script>";
	}
  }
    else if(isset($_POST['sendacct'])!="")
  {
		$uname=$_POST['uname'];
		$pword=$_POST['pword'];
		$description=$_POST['description'];
		$active=$_POST['active'];
		
		$sql="INSERT INTO account(uname,pword,description,active)VALUES('$uname','$pword','$description','$active')";
		$result = mysqli_query($conn,$sql)  or die (mysqli_error($conn));
  
	if($result)
	{
      $msg="Successfully Updated!!";
      echo "<script type='text/javascript'>alert('$msg');</script>";
      header('Location:accounts.php');
	}
	else
	{
     $errormsg="Something went wrong, Try again";
      echo "<script type='text/javascript'>alert('$errormsg');</script>";
	}
  }
  else if(isset($_POST['sendstud']) != ""){
		$var1=$_POST['ln'];
		$var2=$_POST['fn'];
		$var3=$_POST['mn'];
		$var4=$_POST['gen'];
		$var5=$_POST['bdate'];
		//$var6=$_POST['prog'];
		//$var7=$_POST['nation'];
		//$var8=$_POST['rel'];
		$var9=$_POST['reg'];
		$var10=$_POST['yr'];
		
		$sql="INSERT INTO student(lastname,firstname,middlename,gender,birthdate,regular,year)VALUES('$var1','$var2','$var3','$var4','$var5','$var9','$var10') ";
		$result = mysqli_query($conn,$sql)  or die (mysqli_error($conn));;
  
	if($result)
	{
      $msg="Successfully Updated!!";
      echo "<script type='text/javascript'>alert('$msg');</script>";
      header('Location:student.php');
	}
	else
	{
     $errormsg="Something went wrong, Try again";
      echo "<script type='text/javascript'>alert('$errormsg');</script>";
	}
  }
 ob_end_flush();
?>